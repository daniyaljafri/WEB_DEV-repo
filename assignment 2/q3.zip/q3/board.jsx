import React, { useEffect, useState } from "react";


export const Board = () => {

    const [Teams, setdata] = useState([])

    const getdata = async () => {

        const respone = await fetch('http://localhost:5000', {
            method: "GET",

        })

        const teamsdata =await respone.json()
        console.log(teamsdata)
        setdata(teamsdata.data)
        console.log(Teams)

    }

    useEffect(() => {
        getdata()
    }, [])


    return (
        <div>
            <table >
                <tr>
                    <th>Rank</th>
                    <th>Team Name</th>
                    <th>Total Games Played</th>
                    <th>Score</th>

                </tr>
                
                {Teams.map((curr, index) => {
                        const { Name, image, Games, Score } = curr
                        return (
                            
                                <tr  >
                                    
                                    {(index ==0) ? (
                                           <td className=" flex justify-center">
                                            <img className="h-10 w-10 rounded-full " src={require('../trophies/gold.png')} alt="" />

                                           </td>                                        
                                    ):(
                                        (index ==1) ?(
                                            <td className=" flex justify-center">
                                            <img className="h-10 w-10 rounded-full " src={require('../trophies/silver.jpeg')} alt="" />

                                           </td> 
                                        ):(
                                            (index ==2) ?(
                                                <td className=" flex justify-center">
                                                <img className="h-10 w-10 rounded-full " src={require('../trophies/bronze.jpeg')} alt="" />
    
                                               </td> 
                                            ):(
                                                <td>
                                                    {index+1}
                                                </td>
                                            )
                                        )
                                    )
                                    }                                    
                                  <td>
                                    {Name}

                                    </td>
                                    <td>
                                    {Games}

                                    </td>
                                    <td>
                                    {Score}

                                    </td>
                                </tr>
                        )
                    })
                }
            </table>
        </div>
    )
}





const express =require('express')
const cors=require('cors')
const connectdb=require('./db')
const teams=require('./mteams')



const app =express()

app.use(cors())

app.use(express.json())


connectdb().then(() => {
    app.listen(5000,()=>{
        console.log("server running")
        
    })
    
    
}).catch((err) => {
    console.log("Server not started ")
});



app.route('/')
.get(async(req,res)=>{
    try {
        const team=await teams.find().sort({Score:-1})
        res.status(200).json({data:team})


    } catch (error) {
        res.status(401).json({msg:"error in data"})
    }
})
.post(async(req,res)=>{

    try {
        const{Name,Image,Games,Score}=req.body
        const teamcreated=await teams.create({Name,Image,Games,Score})


        res.status(202).json({
            msg: teamcreated

        })


    } catch (error) {
        res.send(error)


    }


})


const mongoose=require("mongoose");


const team_scheme=new mongoose.Schema({
    
    Name:{
        type:String,
        required:true
    },
    Image:{
        type:String,
        required:true

    },
    
    Games:{
        type:Number,
        required:true
    },
    Score:{
        type:Number,
        required:true
    }

})

const teams=new mongoose.model('Teams',team_scheme)

module.exports=teams

const mongoose=require('mongoose')


const URI='mongodb+srv://ahmedgull510:scorpio1000p@cluster0.rpbuoni.mongodb.net/Assignment?retryWrites=true&w=majority&appName=Cluster0'

const connectdb = async () => {
    try {
        await mongoose.connect(URI)
        console.log("conneted ")
    } catch (error) {
        console.log("NOT connected")

    }
}

module.exports=connectdb;